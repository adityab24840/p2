package com.example.adding;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class Screen2 extends AppCompatActivity {

    TextView answer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        answer = findViewById(R.id.result);

        Bundle bund = getIntent().getExtras();
        String summ = bund.getString("Result");
        answer.setText(summ);

    }
}